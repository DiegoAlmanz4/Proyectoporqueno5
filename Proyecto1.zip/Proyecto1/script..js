// === ELEMENTOS DEL DOM ===
const mario = document.getElementById('mario');
const mundoJuego = document.getElementById('mundo-juego');
const contadorMonedas = document.getElementById('contador-monedas');
const contadorPuntos = document.getElementById('contador-puntos');
const contadorVidas = document.getElementById('contador-vidas');
const gameOverModal = document.getElementById('game-over-modal');
const puntuacionFinal = document.getElementById('puntuacion-final');
const reiniciarBtn = document.getElementById('reiniciar-btn');
const enemigo = document.getElementById('enemigo');

// === VARIABLES DEL JUEGO ===
let posicionMario = { x: 100, y: 0 }; // Posición actual (y=0 significa en el suelo)
let velocidadY = 0;
let enSuelo = true;
let monedasRecogidas = 0;
let puntos = 0;
let vidas = 3;
let juegoActivo = true;
let teclas = {};

// === CONFIGURACIÓN DE FÍSICA ===
const gravedad = 0.5;
const velocidadMovimiento = 5;
const velocidadSalto = -12;
const alturaSuelo = 50; // Altura del suelo desde abajo
let plataformas = [];

// === INICIALIZAR PLATAFORMAS ===
function inicializarPlataformas() {
    plataformas = []; // Limpiar array
    const plataformasDOM = document.querySelectorAll('.plataforma');
    plataformasDOM.forEach(plat => {
        plataformas.push({
            elemento: plat,
            x: plat.offsetLeft,
            y: mundoJuego.clientHeight - plat.offsetTop - plat.clientHeight,
            width: plat.clientWidth,
            height: plat.clientHeight
        });
    });
}

// === MOVIMIENTO DE MARIO ===
function actualizarMario() {
    if (!juegoActivo) {
        requestAnimationFrame(actualizarMario);
        return;
    }

    // Movimiento horizontal
    if (teclas['ArrowLeft'] || teclas['Left']) {
        posicionMario.x -= velocidadMovimiento;
        mario.classList.add('caminando');
        mario.style.transform = 'scaleX(-1)'; // Voltear Mario hacia la izquierda
    } else if (teclas['ArrowRight'] || teclas['Right']) {
        posicionMario.x += velocidadMovimiento;
        mario.classList.add('caminando');
        mario.style.transform = 'scaleX(1)'; // Mario hacia la derecha
    } else {
        mario.classList.remove('caminando');
    }

    // Límites del mundo
    posicionMario.x = Math.max(0, Math.min(posicionMario.x, mundoJuego.clientWidth - 40));

    // Gravedad y salto
    if (teclas['Space'] && enSuelo) {
        velocidadY = velocidadSalto;
        enSuelo = false;
        mario.classList.add('saltando');
        setTimeout(() => mario.classList.remove('saltando'), 500);
    }

    // Aplicar gravedad
    velocidadY += gravedad;
    posicionMario.y += velocidadY;

    // Colisión con el suelo
    if (posicionMario.y >= 0) {
        posicionMario.y = 0;
        velocidadY = 0;
        enSuelo = true;
    }

    // Colisión con plataformas
    verificarColisionPlataformas();

    // Actualizar posición visual
    mario.style.bottom = (posicionMario.y + alturaSuelo) + 'px';
    mario.style.left = posicionMario.x + 'px';

    // Verificar colisión con monedas
    verificarColisionMonedas();

    // Verificar colisión con enemigo
    verificarColisionEnemigo();

    requestAnimationFrame(actualizarMario);
}

// === VERIFICAR COLISIÓN CON PLATAFORMAS ===
function verificarColisionPlataformas() {
    plataformas.forEach(plataforma => {
        // Colisión desde arriba
        if (posicionMario.x + 40 > plataforma.x &&
            posicionMario.x < plataforma.x + plataforma.width &&
            posicionMario.y <= plataforma.y + plataforma.height &&
            posicionMario.y + 50 >= plataforma.y &&
            velocidadY >= 0) {
            
            posicionMario.y = plataforma.y + plataforma.height;
            velocidadY = 0;
            enSuelo = true;
        }
    });
}

// === VERIFICAR COLISIÓN CON MONEDAS ===
function verificarColisionMonedas() {
    const monedas = document.querySelectorAll('.moneda:not(.moneda-recogida)');
    monedas.forEach(moneda => {
        const rectMoneda = moneda.getBoundingClientRect();
        const rectMario = mario.getBoundingClientRect();

        if (rectMario.left < rectMoneda.right &&
            rectMario.right > rectMoneda.left &&
            rectMario.top < rectMoneda.bottom &&
            rectMario.bottom > rectMoneda.top) {
            
            // Recoger moneda
            moneda.classList.add('moneda-recogida');
            setTimeout(() => moneda.remove(), 500);
            
            // Actualizar puntuación
            monedasRecogidas++;
            puntos += 10;
            actualizarPuntuacion();
            
            // Efecto de sonido virtual
            console.log('🪙 ¡Moneda recogida!');
        }
    });
}

// === VERIFICAR COLISIÓN CON ENEMIGO ===
function verificarColisionEnemigo() {
    const rectMario = mario.getBoundingClientRect();
    const rectEnemigo = enemigo.getBoundingClientRect();

    if (rectMario.left < rectEnemigo.right &&
        rectMario.right > rectEnemigo.left &&
        rectMario.top < rectEnemigo.bottom &&
        rectMario.bottom > rectEnemigo.top) {
        
        // Mario saltó sobre el enemigo?
        if (velocidadY < 0 && rectMario.bottom < rectEnemigo.top + 20) {
            // ¡Derrotó al enemigo!
            enemigo.style.animation = 'none';
            enemigo.style.opacity = '0';
            setTimeout(() => {
                enemigo.style.left = '400px';
                enemigo.style.opacity = '1';
                enemigo.style.animation = 'pasear 3s infinite alternate';
            }, 1000);
            
            puntos += 50;
            actualizarPuntuacion();
        } else {
            // Mario fue golpeado
            perderVida();
        }
    }
}

// === PERDER VIDA ===
function perderVida() {
    vidas--;
    contadorVidas.textContent = vidas;
    
    // Animación de daño
    mario.style.filter = 'brightness(200%)';
    setTimeout(() => mario.style.filter = 'brightness(100%)', 200);
    
    if (vidas <= 0) {
        gameOver();
    } else {
        // Reiniciar posición
        posicionMario.x = 100;
        posicionMario.y = 0;
        velocidadY = 0;
    }
}

// === ACTUALIZAR PUNTUACIÓN ===
function actualizarPuntuacion() {
    contadorMonedas.textContent = monedasRecogidas;
    contadorPuntos.textContent = puntos;
}

// === GAME OVER ===
function gameOver() {
    juegoActivo = false;
    puntuacionFinal.textContent = `Puntuación final: ${puntos} 🏆`;
    gameOverModal.classList.add('mostrar');
}

// === REINICIAR JUEGO ===
function reiniciarJuego() {
    location.reload();
}

// === EVENTOS DE TECLADO ===
document.addEventListener('keydown', (e) => {
    if (!juegoActivo) return;
    
    teclas[e.key] = true;
    
    // Prevenir scroll con las flechas y espacio
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown' || 
        e.key === 'ArrowLeft' || e.key === 'ArrowRight' || 
        e.key === ' ') {
        e.preventDefault();
    }
});

document.addEventListener('keyup', (e) => {
    teclas[e.key] = false;
});

// También manejar el caso de que se pierda el foco de la ventana
window.addEventListener('blur', () => {
    teclas = {}; // Resetear teclas si la ventana pierde el foco
});

// === INICIALIZACIÓN ===
window.addEventListener('load', () => {
    inicializarPlataformas();
    actualizarMario();
    
    // Crear algunas monedas adicionales cada cierto tiempo
    setInterval(() => {
        if (juegoActivo && Math.random() < 0.3) {
            const nuevaMoneda = document.createElement('div');
            nuevaMoneda.className = 'moneda';
            nuevaMoneda.style.bottom = Math.random() * 400 + 50 + 'px';
            nuevaMoneda.style.left = Math.random() * 700 + 'px';
            nuevaMoneda.textContent = '🪙';
            mundoJuego.appendChild(nuevaMoneda);
        }
    }, 5000);
});

// Botón de reiniciar
reiniciarBtn.addEventListener('click', reiniciarJuego);