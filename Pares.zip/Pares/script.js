let carta1 = null;
let carta2 = null;
let bloqueado = false;
let paresEncontrados = 0;
const totalPares = 8;

const imagenes = {
    1: 'img/Foca1.jpn.pnj',
    2: 'img/Foca2.jpn.pnj',
    3: 'img/Foca3.jpn.pnj',
    4: 'img/Foca4.jpn.pnj',
    5: 'img/Foca5.jpn.pnj',
    6: 'img/Foca6.jpn.pnj',
    7: 'img/Foca7.jpn.pnj',
    8: 'img/focagorda.jpn.pnj'
};

function seleccionarCarta(carta) {
    if (bloqueado || carta === carta1 || carta.classList.contains('ganadora')) {
        return;
    }

    let numeroPar = carta.getAttribute('data-par');
    carta.src = imagenes[numeroPar];
    carta.style.backgroundImage = 'none';
    
    if (carta1 === null) {
        carta1 = carta;
    } else {
        carta2 = carta;
        compararCartas();
    }
}

function compararCartas() {
    bloqueado = true;
    
    if (carta1.getAttribute('data-par') === carta2.getAttribute('data-par')) {
        parCorrecto(carta1, carta2);
    } else {
        parIncorrecto(carta1, carta2);
    }
}

function parCorrecto(carta1, carta2) {
    carta1.classList.add('ganadora');
    carta2.classList.add('ganadora');
    
    paresEncontrados++;
    document.getElementById('score').innerHTML = 'Pares: ' + paresEncontrados + '/8';
    
    if (paresEncontrados === totalPares) {
        setTimeout(function() {
            alert('Ganaste Ganador');
        }, 200);
    }
    
    reiniciarSeleccion();
}

function parIncorrecto(carta1, carta2) {
    setTimeout(function() {
        carta1.src = '';
        carta2.src = '';
        carta1.style.backgroundImage = "url('img/back.jpg')";
        carta2.style.backgroundImage = "url('img/back.jpg')";
        reiniciarSeleccion();
    }, 500);
}

function reiniciarSeleccion() {
    carta1 = null;
    carta2 = null;
    bloqueado = false;
}

function reiniciarJuego() {
    let cartas = document.querySelectorAll('.carta');
    for (let i = 0; i < cartas.length; i++) {
        cartas[i].src = '';
        cartas[i].style.backgroundImage = "url('img/back.jpg')";
        cartas[i].classList.remove('ganadora');
    }
    
    carta1 = null;
    carta2 = null;
    bloqueado = false;
    paresEncontrados = 0;
    document.getElementById('score').innerHTML = 'Pares: 0/8';
}

window.onload = function() {
    reiniciarJuego();
};